﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StandAutomoveis
{
    public partial class CarroOficina
    {
        public CarroOficina(string combustivel, string kms, string marca, string matricula, string modelo, string nrChassis)
        {
            this.Combustivel = combustivel;
            //this.
        }

        public override string ToString()
        {
            return "";
        }
    }
}
