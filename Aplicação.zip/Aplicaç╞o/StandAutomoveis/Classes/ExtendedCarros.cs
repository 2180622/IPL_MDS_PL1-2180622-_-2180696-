﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StandAutomoveis
{
    public partial class Carros
    {
        public override string ToString()
        {
            return " ";
        }
    }
}
