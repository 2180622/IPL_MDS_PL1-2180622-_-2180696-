﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StandAutomoveis
{
    public partial class FormCarroOficina : Form
    {
        public FormCarroOficina()
        {
            InitializeComponent();
        }

        private void buttonAddCarroOficina_Click(object sender, EventArgs e)
        {
            CarroOficina novocarrOficina = new CarroOficina();


        }

        private void buttonExitApp_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
